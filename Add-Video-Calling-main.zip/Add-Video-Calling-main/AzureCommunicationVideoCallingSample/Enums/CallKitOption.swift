//
//  CallKitOption.swift
//  AzureCommunicationVideoCallingSample
//
//  Created by Hyounwoo Sung on 2021/02/10.
//

enum CallKitOption {
    case disabled
    case incoming
    case outgoing
}
